import React, { Fragment, useState } from "react";
import Select from "react-select";
import { useFormik } from "formik";
import { addProductSchema } from "../schemas";

import {
  segment,
  subCategory,
  region,
  country,
  baseUnitOfMeasurement,
  innerUnitOfMeasurement,
  options,
} from "../data";
// import { Combobox, Transition } from "@headlessui/react";
// import { CheckIcon, ChevronUpDownIcon } from '@heroicons/react/20/solid'
// import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";

function BulkEditTable() {


  return (
    <>
  
    </>
  );
}

export default BulkEditTable;
