function createArrayWithNumber(num) {
  const resultArray = [];
  for (let i = 0; i < num; i++) {
    resultArray.push(i);
  }

  return resultArray;
}

export default createArrayWithNumber;
