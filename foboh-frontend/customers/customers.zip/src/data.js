import React from "react";

function data() {
  ["NSW", "VIC", "QLD", "WA", "SA", "TAS", "ACT", "NT"];
}

export default data;
