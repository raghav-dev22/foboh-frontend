// WEBPACK URLS



// API URLS
export const user_api_url = "https://user-api-foboh.azurewebsites.net"


