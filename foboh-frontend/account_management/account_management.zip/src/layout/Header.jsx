import React from 'react'
import fobohLogo from '../image/signup/fobohLogo.png'

const Header = () => {
  return (
    <>
      
    </>
  )
}

export default Header