import React from 'react'

function Range() {
  return (
    <div>
      
    </div>
  )
}

export default Range
