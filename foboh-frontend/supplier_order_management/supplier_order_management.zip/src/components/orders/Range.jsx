import React, { useEffect, useRef, useState } from "react";

import "../style.css";

function Range() {
  return (
    <>
      <h1>kjshedhedh</h1>
    </>
  );
}

export default Range;
